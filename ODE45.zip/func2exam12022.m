function [dy] = func2exam12022(t,y1,y2)
  dy = 0;

dy = cos(2*pi*t) - y2;

