function [dy] = func1_sysexam12020(t,y1,y2)
  dy = 0;

dy =  t^2 + 30.0*sin(y2);

