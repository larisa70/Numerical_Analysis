
function dy = func_example3(t, y)

  dy = 0;

dy =  sin(t*y);
%dy(1) =  t^2 + sin(t*y);
