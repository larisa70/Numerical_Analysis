function [dy] = func1_sys(t,y1,y2)
  dy = 0;

dy = y2 + 2*t;

