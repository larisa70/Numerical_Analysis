function [dy] = func2_sysexam12020(t,y1,y2)
  dy = 0;

dy = t + 30.0*cos(y1);

