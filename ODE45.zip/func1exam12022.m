function [dy] = func1exam12022(t,y1,y2)
  dy = 0;

dy = sin(2*pi*t) + y1;

