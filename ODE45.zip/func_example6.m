
function dy = func_example4(t, y)

  dy = 0;

%dy(1) =  t + 2*y;
dy(1) =  -20*y;
