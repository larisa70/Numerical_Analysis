function [dy] = func_problem1(t,y)
  dy = 0;

dy = sin(t*y);
