function [dy] = func_problem2(t,y)
  dy = 0;

dy = t^2 + sin(y);
