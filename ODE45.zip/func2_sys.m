function [dy] = func2_sys(t,y1,y2)
  dy = 0;

dy = y1 - 2*t*y1 + y2 - t + 1;

