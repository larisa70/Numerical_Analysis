function [dy] = func1_exam22018(t,y1,y2)
%  dy = 0;

dy = y2;

