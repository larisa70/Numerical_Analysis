function [dy] = func2_exam22018(t,y1,y2)
%  dy = 0;

dy = y1  + y2;

