
function [dy] = func(t,y)
  dy = 0;

dy = y;
